'use strict'

app.factory("SharedStateService", function() {
                    return {
                        clickedWanna: 'SharedStateService'
                    };
            });
