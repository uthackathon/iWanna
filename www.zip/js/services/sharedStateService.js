'use strict'

app.factory("SharedStateService", function() {
                    return {
                        clickedWanna: 'SharedStateService',
                        friendImages: {'initUid':'initImg'},
                        clickedFriendId: 'SharedStateService'
                    };
            });
