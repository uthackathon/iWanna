'use strict'

app.factory("SharedStateServiceForMessage", function() {
                    return {
                        chosenRoomId: 'SharedStateServiceForMessage'
                    };
            });